#ifndef _SPARC64_SEMAPHORE_H
#define _SPARC64_SEMAPHORE_H

/* These are actually reasonable on the V9.
 *
 * See asm-ppc/semaphore.h for implementation commentary,
 * only sparc64 specific issues are commented here.
 */
#endif /* !(_SPARC64_SEMAPHORE_H) */
