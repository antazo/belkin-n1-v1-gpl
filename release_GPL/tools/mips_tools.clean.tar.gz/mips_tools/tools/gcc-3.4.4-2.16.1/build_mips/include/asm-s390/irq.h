#ifndef _ASM_IRQ_H
#define _ASM_IRQ_H

#endif

