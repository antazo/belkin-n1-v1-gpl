#ifndef _ASM_SPARC64_MODULE_H
#define _ASM_SPARC64_MODULE_H
struct mod_arch_specific { };
#define Elf_Shdr Elf64_Shdr
#define Elf_Sym Elf64_Sym
#define Elf_Ehdr Elf64_Ehdr
#endif /* _ASM_SPARC64_MODULE_H */
