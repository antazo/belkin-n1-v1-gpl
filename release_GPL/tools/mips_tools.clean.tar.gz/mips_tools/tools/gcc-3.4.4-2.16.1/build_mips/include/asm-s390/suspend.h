#ifndef __ASM_S390_SUSPEND_H
#define __ASM_S390_SUSPEND_H

#endif

