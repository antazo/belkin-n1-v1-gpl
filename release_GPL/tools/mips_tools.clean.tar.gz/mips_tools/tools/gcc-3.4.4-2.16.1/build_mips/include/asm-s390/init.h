/*
 *  include/asm-s390/init.h
 *
 *  S390 version
 */

#error "<asm/init.h> should never be used - use <linux/init.h> instead"
