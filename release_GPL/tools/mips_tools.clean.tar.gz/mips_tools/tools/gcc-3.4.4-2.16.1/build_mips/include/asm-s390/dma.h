/*
 *  include/asm-s390/dma.h
 *
 *  S390 version
 */

#ifndef _ASM_DMA_H
#define _ASM_DMA_H

#include <asm/io.h>		/* need byte IO */

#define MAX_DMA_ADDRESS         0x80000000

#define free_dma(x)

#endif /* _ASM_DMA_H */
