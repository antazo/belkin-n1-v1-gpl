#ifndef __ASM_SUSPEND_H
#define __ASM_SUSPEND_H

/* Somewhen...  Maybe :-)  */

#endif /* __ASM_SUSPEND_H */
