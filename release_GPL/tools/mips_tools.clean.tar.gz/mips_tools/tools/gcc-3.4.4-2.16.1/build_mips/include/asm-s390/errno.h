/*
 *  include/asm-s390/errno.h
 *
 *  S390 version
 *
 */

#ifndef _S390_ERRNO_H
#define _S390_ERRNO_H

#ifndef _LINUX_ERRNO_H
 #include <linux/errno.h>
#endif

#endif
