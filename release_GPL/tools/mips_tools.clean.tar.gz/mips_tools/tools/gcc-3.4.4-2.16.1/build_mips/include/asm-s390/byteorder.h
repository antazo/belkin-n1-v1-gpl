#ifndef _S390_BYTEORDER_H
#define _S390_BYTEORDER_H

#include <linux/byteorder/big_endian.h>

#endif /* _S390_BYTEORDER_H */
